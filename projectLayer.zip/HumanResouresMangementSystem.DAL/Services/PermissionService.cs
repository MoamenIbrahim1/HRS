﻿using HumanResouresMangementSystem.Data;
using Microsoft.EntityFrameworkCore;
using System;

namespace HumanResouresMangementSystem.Core.Services
{
    public class PermissionService:IPermissionService
    {
        private readonly AppDbContext _context;

        public PermissionService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<bool> HasPermissionAsync(
            int userId,
            string permissionName)
        {
            return await _context.GroupPermissions
                .AnyAsync(x =>
                    x.Group.Users.Any(u => u.Id == userId) &&
                    x.Permission.Name == permissionName);
        }
    }
}